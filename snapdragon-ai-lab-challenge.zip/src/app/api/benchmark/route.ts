import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { benchmarks } from "@/db/schema";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { testName, score, deviceInfo, npuUtilization, cpuUtilization } = body;

    if (!testName || typeof score !== "number") {
      return NextResponse.json(
        { error: "Test name and score are required" },
        { status: 400 }
      );
    }

    // Save benchmark result
    const [savedBenchmark] = await db.insert(benchmarks).values({
      testName,
      score,
      deviceInfo: deviceInfo || {},
      npuUtilization: npuUtilization || 0,
      cpuUtilization: cpuUtilization || 0
    }).returning();

    return NextResponse.json({
      success: true,
      benchmark: savedBenchmark,
      message: "Benchmark saved successfully"
    });

  } catch (error) {
    console.error("Benchmark API error:", error);
    return NextResponse.json(
      { error: "Failed to save benchmark" },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const recentBenchmarks = await db.select().from(benchmarks).orderBy(benchmarks.createdAt).limit(20);
    
    // Calculate averages
    const avgScore = recentBenchmarks.length > 0
      ? recentBenchmarks.reduce((sum, b) => sum + b.score, 0) / recentBenchmarks.length
      : 0;

    const avgNpuUtil = recentBenchmarks.length > 0
      ? recentBenchmarks.reduce((sum, b) => sum + (b.npuUtilization || 0), 0) / recentBenchmarks.length
      : 0;

    return NextResponse.json({
      success: true,
      benchmarks: recentBenchmarks,
      stats: {
        averageScore: avgScore,
        averageNpuUtilization: avgNpuUtil,
        totalRuns: recentBenchmarks.length
      }
    });
  } catch (error) {
    console.error("Get benchmarks error:", error);
    return NextResponse.json(
      { error: "Failed to fetch benchmarks" },
      { status: 500 }
    );
  }
}
