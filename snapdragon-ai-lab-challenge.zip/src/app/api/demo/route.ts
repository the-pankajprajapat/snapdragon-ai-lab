import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { aiDemos } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { demoType, inputData } = body;

    if (!demoType || !["image", "text", "benchmark"].includes(demoType)) {
      return NextResponse.json(
        { error: "Invalid demo type" },
        { status: 400 }
      );
    }

    // Simulate AI processing with Snapdragon NPU optimization
    const startTime = Date.now();
    
    // Simulate different processing times based on demo type
    const processingDelays: Record<string, number> = {
      image: 45,  // NPU-accelerated image processing
      text: 32,   // NLP with Hexagon NPU
      benchmark: 28 // Optimized benchmark
    };

    // Simulate processing delay (representing NPU acceleration)
    await new Promise(resolve => setTimeout(resolve, processingDelays[demoType] || 50));
    
    const processingTimeMs = Date.now() - startTime;

    // Generate result based on demo type
    let resultData: Record<string, unknown> = {};
    
    switch (demoType) {
      case "image":
        resultData = {
          analysis: "Professional workspace detected",
          objects: ["HP Laptop", "Monitor", "Keyboard", "Mouse"],
          confidence: 0.96,
          npuAccelerated: true,
          processingTimeMs
        };
        break;
      case "text":
        resultData = {
          sentiment: "positive",
          confidence: 0.94,
          keywords: ["AI", "Snapdragon", "performance", "innovation"],
          npuAccelerated: true,
          processingTimeMs
        };
        break;
      case "benchmark":
        resultData = {
          npuScore: 9847,
          cpuScore: 8234,
          efficiency: 0.89,
          improvement: "3.2x faster than CPU-only",
          npuAccelerated: true,
          processingTimeMs
        };
        break;
    }

    // Store result in database
    const [savedDemo] = await db.insert(aiDemos).values({
      demoType,
      inputData: inputData || {},
      resultData,
      processingTimeMs,
      snapdragonOptimized: "true"
    }).returning();

    return NextResponse.json({
      success: true,
      result: resultData,
      processingTimeMs,
      snapdragonOptimized: true,
      id: savedDemo?.id
    });

  } catch (error) {
    console.error("Demo API error:", error);
    return NextResponse.json(
      { error: "Failed to process demo" },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const recentDemos = await db.select().from(aiDemos).orderBy(sql`${aiDemos.createdAt} DESC`).limit(10);
    
    return NextResponse.json({
      success: true,
      demos: recentDemos
    });
  } catch (error) {
    console.error("Get demos error:", error);
    return NextResponse.json(
      { error: "Failed to fetch demos" },
      { status: 500 }
    );
  }
}
