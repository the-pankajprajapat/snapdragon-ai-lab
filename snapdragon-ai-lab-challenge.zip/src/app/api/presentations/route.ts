import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { presentations } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, description, slides, author, category } = body;

    if (!title || !author) {
      return NextResponse.json(
        { error: "Title and author are required" },
        { status: 400 }
      );
    }

    const validCategories = ["ai_vision", "nlp", "performance", "innovation"];
    if (category && !validCategories.includes(category)) {
      return NextResponse.json(
        { error: "Invalid category" },
        { status: 400 }
      );
    }

    // Save presentation
    const [savedPresentation] = await db.insert(presentations).values({
      title,
      description: description || "",
      slides: slides || [],
      author,
      category: category || "innovation",
      views: 0
    }).returning();

    return NextResponse.json({
      success: true,
      presentation: savedPresentation,
      message: "Presentation submitted successfully"
    });

  } catch (error) {
    console.error("Presentation API error:", error);
    return NextResponse.json(
      { error: "Failed to submit presentation" },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const limit = parseInt(searchParams.get("limit") || "20");

    let allPresentations;
    
    if (category) {
      allPresentations = await db.select().from(presentations)
        .where(sql`${presentations.category} = ${category}`)
        .orderBy(sql`${presentations.views} DESC`)
        .limit(limit);
    } else {
      allPresentations = await db.select().from(presentations)
        .orderBy(sql`${presentations.views} DESC`)
        .limit(limit);
    }

    return NextResponse.json({
      success: true,
      presentations: allPresentations
    });
  } catch (error) {
    console.error("Get presentations error:", error);
    return NextResponse.json(
      { error: "Failed to fetch presentations" },
      { status: 500 }
    );
  }
}
