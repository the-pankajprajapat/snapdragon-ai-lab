"use client";

import { motion } from "framer-motion";
import { 
  ArrowLeft, 
  Cpu, 
  Zap, 
  Brain, 
  Shield, 
  Globe, 
  Award,
  Users,
  Target
} from "lucide-react";
import Link from "next/link";

export default function AboutPage() {
  const technologies = [
    {
      name: "Hexagon NPU",
      description: "Qualcomm's dedicated Neural Processing Unit delivers up to 45 TOPS for AI workloads",
      icon: Brain,
      specs: ["45 TOPS peak performance", "INT8/FP16 precision", "Hardware acceleration"]
    },
    {
      name: "Adreno GPU",
      description: "Advanced graphics processing with AI acceleration capabilities",
      icon: Zap,
      specs: ["Ray tracing support", "Variable rate shading", "AI-enhanced rendering"]
    },
    {
      name: "Kryo CPU",
      description: "High-performance ARM-based CPU cores for general computing",
      icon: Cpu,
      specs: ["8-core configuration", "3.0+ GHz clock speed", "Efficient power management"]
    },
    {
      name: "Security Engine",
      description: "Hardware-backed security for AI models and data protection",
      icon: Shield,
      specs: ["Secure boot", "Encrypted AI models", "Trusted execution environment"]
    }
  ];

  const benefits = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Up to 3.2x faster AI inference compared to CPU-only processing"
    },
    {
      icon: Shield,
      title: "Privacy First",
      description: "On-device processing ensures your data never leaves your PC"
    },
    {
      icon: Target,
      title: "Power Efficient",
      description: "89% better power efficiency for all-day AI workloads"
    },
    {
      icon: Globe,
      title: "Always Connected",
      description: "5G connectivity with AI-optimized network management"
    }
  ];

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="glass sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </Link>
          <div className="flex items-center gap-3">
            <Cpu className="w-6 h-6 text-orange-400" />
            <span className="text-xl font-bold gradient-text">About Snapdragon AI</span>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Powered by <span className="gradient-text">Snapdragon</span>
            </h1>
            <p className="text-xl text-gray-400 mb-8">
              The most advanced AI platform for Windows PCs, optimized for HP devices
            </p>
          </motion.div>

          {/* Hero Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12"
          >
            {[
              { value: "45", suffix: " TOPS", label: "NPU Performance" },
              { value: "3.2", suffix: "x", label: "AI Speed Boost" },
              { value: "89", suffix: "%", label: "Power Efficiency" },
              { value: "100", suffix: "%", label: "On-Device AI" }
            ].map((stat, i) => (
              <motion.div
                key={i}
                whileHover={{ scale: 1.05 }}
                className="glass rounded-2xl p-6"
              >
                <div className="text-4xl font-bold gradient-text mb-2">
                  {stat.value}{stat.suffix}
                </div>
                <div className="text-sm text-gray-400">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-16 px-6 bg-gradient-to-b from-transparent via-card-bg/30 to-transparent">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">
              AI <span className="gradient-text-cyan">Technology Stack</span>
            </h2>
            <p className="text-xl text-gray-400">
              Built on Qualcomm's advanced heterogeneous computing architecture
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6">
            {technologies.map((tech, i) => (
              <motion.div
                key={tech.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass rounded-2xl p-8"
              >
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
                    <tech.icon className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-2">{tech.name}</h3>
                    <p className="text-gray-400">{tech.description}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  {tech.specs.map((spec, j) => (
                    <div key={j} className="flex items-center gap-3 text-sm">
                      <div className="w-2 h-2 rounded-full bg-orange-400" />
                      <span className="text-gray-300">{spec}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">
              Why Choose <span className="gradient-text">Snapdragon AI</span>
            </h2>
            <p className="text-xl text-gray-400">
              Experience the advantages of dedicated AI hardware
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ scale: 1.03 }}
                className="glass rounded-2xl p-6 text-center"
              >
                <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center mx-auto mb-4">
                  <benefit.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-3">{benefit.title}</h3>
                <p className="text-gray-400">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* HP Partnership */}
      <section className="py-16 px-6 bg-gradient-to-b from-transparent via-card-bg/30 to-transparent">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass rounded-3xl p-12"
          >
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold mb-6">
                  Optimized for <span className="gradient-text">HP PCs</span>
                </h2>
                <p className="text-gray-400 mb-6">
                  HP and Qualcomm have partnered to deliver the best Snapdragon experience on Windows PCs. 
                  Our devices are specifically tuned to maximize AI performance while maintaining exceptional 
                  battery life and thermal efficiency.
                </p>
                <ul className="space-y-4">
                  {[
                    "Custom thermal design for sustained AI workloads",
                    "Optimized power delivery for NPU acceleration",
                    "HP AI Companion software integration",
                    "Enterprise-grade security features"
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-green-400" />
                      </div>
                      <span className="text-gray-300">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative">
                <div className="aspect-square rounded-3xl bg-gradient-to-br from-orange-500/20 to-red-500/20 flex items-center justify-center">
                  <div className="text-center">
                    <Award className="w-24 h-24 text-orange-400 mx-auto mb-4" />
                    <div className="text-2xl font-bold gradient-text">HP x Snapdragon</div>
                    <div className="text-gray-400 mt-2">Premium Partnership</div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Developer Resources */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Users className="w-12 h-12 text-orange-400 mx-auto mb-6" />
            <h2 className="text-4xl font-bold mb-6">
              Join the <span className="gradient-text">Developer Community</span>
            </h2>
            <p className="text-xl text-gray-400 mb-8">
              Access comprehensive resources to build amazing AI applications
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary px-8 py-4">
                Download SDK
              </button>
              <button className="btn-secondary px-8 py-4">
                View Documentation
              </button>
              <button className="btn-secondary px-8 py-4">
                Join Discord
              </button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
