"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Cpu, 
  Zap, 
  Brain, 
  Image as ImageIcon, 
  MessageSquare, 
  BarChart3, 
  Rocket, 
  ChevronDown,
  Play,
  CheckCircle,
  TrendingUp,
  Award,
  Layers,
  Sparkles,
  ArrowRight,
  Target,
  Shield
} from "lucide-react";

export default function HomePage() {
  const [activeDemo, setActiveDemo] = useState<"image" | "text" | "benchmark">("image");
  const [isProcessing, setIsProcessing] = useState(false);
  const [demoResult, setDemoResult] = useState<string | null>(null);
  const [scrollY, setScrollY] = useState(0);
  const [windowSize, setWindowSize] = useState({ width: 1920, height: 1080 });

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const runDemo = async (type: typeof activeDemo) => {
    setIsProcessing(true);
    setDemoResult(null);
    
    // Simulate AI processing with Snapdragon NPU
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const results = {
      image: "✓ Image analyzed successfully using Snapdragon NPU. Detected: Professional workspace setup with HP device. Processing time: 45ms (3.2x faster than CPU-only)",
      text: "✓ Text analysis complete. Sentiment: Positive, Confidence: 94%. Snapdragon Hexagon NPU accelerated the transformer model inference.",
      benchmark: "✓ Benchmark complete! NPU Score: 9,847 | CPU Score: 8,234 | Efficiency: 89% | Snapdragon 8cx Gen 4 optimized"
    };
    
    setDemoResult(results[type]);
    setIsProcessing(false);
  };

  const features = [
    {
      icon: <Brain className="w-8 h-8" />,
      title: "Neural Processing Unit",
      description: "Hexagon NPU delivers up to 45 TOPS for lightning-fast AI inference",
      color: "from-orange-500 to-red-500"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Power Efficiency",
      description: "Industry-leading performance per watt for all-day AI workloads",
      color: "from-cyan-500 to-blue-500"
    },
    {
      icon: <Layers className="w-8 h-8" />,
      title: "Multi-Modal AI",
      description: "Vision, NLP, and audio processing running simultaneously",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "On-Device Privacy",
      description: "AI processing happens locally - your data never leaves your device",
      color: "from-green-500 to-emerald-500"
    }
  ];

  const benchmarks = [
    { name: "Image Classification", snapdragon: 98, competitor: 72 },
    { name: "Natural Language", snapdragon: 95, competitor: 68 },
    { name: "Object Detection", snapdragon: 92, competitor: 65 },
    { name: "Speech Recognition", snapdragon: 96, competitor: 71 },
    { name: "Power Efficiency", snapdragon: 99, competitor: 58 }
  ];

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrollY > 50 ? 'glass' : ''}`}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
              <Cpu className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text">Snapdragon AI Lab</span>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="hidden md:flex items-center gap-8"
          >
            <a href="#features" className="text-gray-300 hover:text-white transition-colors">Features</a>
            <a href="#demo" className="text-gray-300 hover:text-white transition-colors">Live Demo</a>
            <a href="#benchmarks" className="text-gray-300 hover:text-white transition-colors">Benchmarks</a>
            <a href="#challenge" className="text-gray-300 hover:text-white transition-colors">Challenge</a>
            <button className="btn-primary">Get Started</button>
          </motion.div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden animated-gradient">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 rounded-full bg-orange-500/30"
              initial={{
                x: Math.random() * windowSize.width,
                y: Math.random() * windowSize.height,
              }}
              animate={{
                y: [null, Math.random() * -200 - 100],
                opacity: [0, 1, 0],
              }}
              transition={{
                duration: Math.random() * 3 + 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6">
              <Sparkles className="w-4 h-4 text-orange-400" />
              <span className="text-sm text-gray-300">Optimized for Snapdragon® Powered HP PCs</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              <span className="gradient-text">AI Lab</span>
              <br />
              <span className="text-white">Build & Present Challenge</span>
            </h1>
            
            <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-10">
              Experience the future of AI computing on Snapdragon-powered devices. 
              Build innovative AI applications that leverage the power of Hexagon NPU 
              for unprecedented performance and efficiency.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-primary flex items-center justify-center gap-2 text-lg px-8 py-4"
                onClick={() => document.getElementById('demo')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <Play className="w-5 h-5" />
                Try Live Demo
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-secondary flex items-center justify-center gap-2 text-lg px-8 py-4"
                onClick={() => document.getElementById('challenge')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <Award className="w-5 h-5" />
                View Challenge
              </motion.button>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20"
          >
            {[
              { value: "45", label: "TOPS NPU Performance", suffix: "" },
              { value: "3.2", label: "x Faster AI Inference", suffix: "x" },
              { value: "89", label: "Power Efficiency", suffix: "%" },
              { value: "100", label: "On-Device Privacy", suffix: "%" }
            ].map((stat, i) => (
              <motion.div
                key={i}
                whileHover={{ scale: 1.05 }}
                className="glass rounded-2xl p-6"
              >
                <div className="text-4xl font-bold gradient-text mb-2">
                  {stat.value}{stat.suffix}
                </div>
                <div className="text-sm text-gray-400">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
        >
          <ChevronDown className="w-8 h-8 text-gray-400" />
        </motion.div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="gradient-text">Snapdragon AI</span> Capabilities
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Built on Qualcomm's advanced AI technology for HP PCs
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ scale: 1.03 }}
                className="glass rounded-2xl p-8 card-hover"
              >
                <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6`}>
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Live Demo Section */}
      <section id="demo" className="py-24 px-6 bg-gradient-to-b from-transparent via-card-bg/50 to-transparent">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="gradient-text-cyan">Live AI Demo</span>
            </h2>
            <p className="text-xl text-gray-400">
              Experience Snapdragon NPU acceleration in real-time
            </p>
          </motion.div>

          <div className="glass rounded-3xl p-8 md:p-12">
            {/* Demo tabs */}
            <div className="flex flex-wrap gap-4 mb-8 justify-center">
              {[
                { id: "image", label: "Image Analysis", icon: ImageIcon },
                { id: "text", label: "Text Processing", icon: MessageSquare },
                { id: "benchmark", label: "Performance Test", icon: BarChart3 }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveDemo(tab.id as typeof activeDemo)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-xl transition-all ${
                    activeDemo === tab.id
                      ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white'
                      : 'glass text-gray-400 hover:text-white'
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Demo content */}
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <AnimatePresence mode="wait">
                  {activeDemo === "image" && (
                    <motion.div
                      key="image"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                    >
                      <div className="aspect-video rounded-2xl bg-gradient-to-br from-purple-900/50 to-blue-900/50 flex items-center justify-center border border-white/10">
                        <ImageIcon className="w-24 h-24 text-gray-600" />
                      </div>
                      <p className="text-gray-400 mt-4 text-center">
                        Upload an image for AI-powered analysis using Snapdragon NPU
                      </p>
                    </motion.div>
                  )}
                  {activeDemo === "text" && (
                    <motion.div
                      key="text"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                    >
                      <textarea
                        className="w-full h-48 rounded-2xl bg-white/5 border border-white/10 p-4 text-white placeholder-gray-500 focus:outline-none focus:border-orange-500"
                        placeholder="Enter text for sentiment analysis, summarization, or translation..."
                      />
                    </motion.div>
                  )}
                  {activeDemo === "benchmark" && (
                    <motion.div
                      key="benchmark"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="space-y-4"
                    >
                      {[
                        { name: "NPU Inference", value: 95 },
                        { name: "CPU Comparison", value: 68 },
                        { name: "Power Efficiency", value: 89 }
                      ].map((item, i) => (
                        <div key={i}>
                          <div className="flex justify-between text-sm mb-2">
                            <span className="text-gray-400">{item.name}</span>
                            <span className="text-orange-400">{item.value}%</span>
                          </div>
                          <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${item.value}%` }}
                              transition={{ duration: 1, delay: i * 0.2 }}
                              className="h-full bg-gradient-to-r from-orange-500 to-red-500 rounded-full"
                            />
                          </div>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="space-y-6">
                <div className="glass rounded-2xl p-6">
                  <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-orange-400" />
                    Snapdragon NPU Acceleration
                  </h3>
                  <ul className="space-y-3">
                    {[
                      "Hardware-accelerated AI inference",
                      "Up to 3x faster than CPU-only",
                      "89% power efficiency improvement",
                      "Real-time processing capabilities"
                    ].map((item, i) => (
                      <li key={i} className="flex items-center gap-3 text-gray-300">
                        <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => runDemo(activeDemo)}
                  disabled={isProcessing}
                  className="w-full btn-primary py-4 flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                      />
                      Processing with NPU...
                    </>
                  ) : (
                    <>
                      <Rocket className="w-5 h-5" />
                      Run AI Demo
                    </>
                  )}
                </motion.button>

                <AnimatePresence>
                  {demoResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="glass rounded-2xl p-6 border-green-500/30"
                    >
                      <div className="flex items-start gap-3">
                        <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-0.5" />
                        <p className="text-gray-300">{demoResult}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benchmarks Section */}
      <section id="benchmarks" className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Performance <span className="gradient-text">Benchmarks</span>
            </h2>
            <p className="text-xl text-gray-400">
              Snapdragon vs Traditional CPU Performance
            </p>
          </motion.div>

          <div className="glass rounded-3xl p-8 md:p-12">
            <div className="space-y-6">
              {benchmarks.map((benchmark, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-gray-300 font-medium">{benchmark.name}</span>
                    <div className="flex gap-4 text-sm">
                      <span className="text-orange-400">Snapdragon: {benchmark.snapdragon}%</span>
                      <span className="text-gray-500">Competitor: {benchmark.competitor}%</span>
                    </div>
                  </div>
                  <div className="relative h-8 bg-white/5 rounded-xl overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${benchmark.snapdragon}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, delay: i * 0.1 }}
                      className="absolute left-0 top-0 h-full bg-gradient-to-r from-orange-500 to-red-500 flex items-center justify-end pr-3"
                    >
                      <span className="text-xs font-bold text-white">Snapdragon</span>
                    </motion.div>
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${benchmark.competitor}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, delay: i * 0.1 + 0.3 }}
                      className="absolute left-0 top-0 h-full bg-gray-600/50 flex items-center justify-end pr-3"
                    >
                      <span className="text-xs text-gray-400">Other</span>
                    </motion.div>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mt-12 grid md:grid-cols-3 gap-6"
            >
              {[
                { icon: TrendingUp, value: "3.2x", label: "Average Performance Gain" },
                { icon: Zap, value: "89%", label: "Power Efficiency" },
                { icon: Target, value: "<50ms", label: "Typical Latency" }
              ].map((stat, i) => (
                <div key={i} className="glass rounded-2xl p-6 text-center">
                  <stat.icon className="w-8 h-8 text-orange-400 mx-auto mb-3" />
                  <div className="text-3xl font-bold gradient-text mb-2">{stat.value}</div>
                  <div className="text-gray-400">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Challenge Section */}
      <section id="challenge" className="py-24 px-6 bg-gradient-to-b from-transparent via-card-bg/50 to-transparent">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-6">
              <Award className="w-4 h-4 text-orange-400" />
              <span className="text-sm text-gray-300">Build & Present Challenge</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Join the <span className="gradient-text">AI Innovation</span> Challenge
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Build groundbreaking AI applications optimized for Snapdragon-powered HP PCs
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {[
              {
                step: "01",
                title: "Build",
                description: "Develop your AI application using Snapdragon Neural Processing SDK",
                icon: Brain
              },
              {
                step: "02",
                title: "Optimize",
                description: "Leverage NPU acceleration for maximum performance and efficiency",
                icon: Zap
              },
              {
                step: "03",
                title: "Present",
                description: "Showcase your innovation to industry experts and compete for prizes",
                icon: Award
              }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="glass rounded-2xl p-8 relative overflow-hidden"
              >
                <div className="absolute top-4 right-4 text-6xl font-bold text-white/5">
                  {item.step}
                </div>
                <item.icon className="w-12 h-12 text-orange-400 mb-6" />
                <h3 className="text-2xl font-bold mb-4">{item.title}</h3>
                <p className="text-gray-400">{item.description}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass rounded-3xl p-8 md:p-12 text-center"
          >
            <h3 className="text-2xl md:text-3xl font-bold mb-6">
              Ready to Start Building?
            </h3>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Access our comprehensive SDK, documentation, and sample projects to kickstart your AI innovation journey on Snapdragon platforms.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary flex items-center justify-center gap-2 px-8 py-4">
                Download SDK
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="btn-secondary flex items-center justify-center gap-2 px-8 py-4">
                View Documentation
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
                  <Cpu className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold gradient-text">Snapdragon AI Lab</span>
              </div>
              <p className="text-gray-400 text-sm">
                Empowering AI innovation on Snapdragon-powered HP PCs
              </p>
            </div>
            {[
              {
                title: "Resources",
                links: ["Documentation", "SDK Download", "Sample Projects", "API Reference"]
              },
              {
                title: "Challenge",
                links: ["Rules & Guidelines", "Submission Portal", "Judging Criteria", "Prizes"]
              },
              {
                title: "Community",
                links: ["Forum", "Discord", "GitHub", "Events"]
              }
            ].map((section, i) => (
              <div key={i}>
                <h4 className="font-bold mb-4">{section.title}</h4>
                <ul className="space-y-2">
                  {section.links.map((link, j) => (
                    <li key={j}>
                      <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="pt-8 border-t border-white/10 text-center text-gray-500 text-sm">
            <p>© 2026 Snapdragon AI Lab Challenge. Optimized for Snapdragon® Powered HP PCs.</p>
            <p className="mt-2">Snapdragon is a product of Qualcomm Technologies, Inc. and/or its subsidiaries.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
