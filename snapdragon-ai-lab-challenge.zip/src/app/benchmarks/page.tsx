"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  ArrowLeft, 
  BarChart3, 
  Cpu, 
  Zap, 
  TrendingUp, 
  Award,
  RefreshCw,
  Download
} from "lucide-react";
import Link from "next/link";

interface BenchmarkData {
  id: string;
  testName: string;
  score: number;
  npuUtilization: number | null;
  cpuUtilization: number | null;
  createdAt: string;
}

export default function BenchmarksPage() {
  const [benchmarks, setBenchmarks] = useState<BenchmarkData[]>([]);
  const [loading, setLoading] = useState(true);
  const [runningTest, setRunningTest] = useState<string | null>(null);

  useEffect(() => {
    fetchBenchmarks();
  }, []);

  const fetchBenchmarks = async () => {
    try {
      const response = await fetch("/api/benchmark");
      const data = await response.json();
      if (data.success) {
        setBenchmarks(data.benchmarks);
      }
    } catch (error) {
      console.error("Failed to fetch benchmarks:", error);
    } finally {
      setLoading(false);
    }
  };

  const runBenchmark = async (testName: string) => {
    setRunningTest(testName);
    
    // Simulate benchmark execution
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const score = Math.floor(Math.random() * 2000) + 8000;
    const npuUtil = Math.floor(Math.random() * 30) + 70;
    const cpuUtil = Math.floor(Math.random() * 40) + 40;

    try {
      await fetch("/api/benchmark", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          testName,
          score,
          deviceInfo: { device: "HP Snapdragon PC", os: "Windows 11" },
          npuUtilization: npuUtil / 100,
          cpuUtilization: cpuUtil / 100
        })
      });
      fetchBenchmarks();
    } catch (error) {
      console.error("Failed to run benchmark:", error);
    } finally {
      setRunningTest(null);
    }
  };

  const testCategories = [
    { name: "Image Classification", icon: "🖼️", description: "ResNet-50 inference on 1000 images" },
    { name: "Natural Language", icon: "💬", description: "BERT model sentiment analysis" },
    { name: "Object Detection", icon: "🎯", description: "YOLOv8 real-time detection" },
    { name: "Speech Recognition", icon: "🎤", description: "Whisper audio transcription" },
    { name: "Power Efficiency", icon: "⚡", description: "Performance per watt measurement" }
  ];

  const stats = {
    averageScore: benchmarks.length > 0 
      ? Math.round(benchmarks.reduce((sum, b) => sum + b.score, 0) / benchmarks.length)
      : 0,
    totalRuns: benchmarks.length,
    avgNpuUtil: benchmarks.length > 0 && benchmarks[0].npuUtilization
      ? Math.round(benchmarks.reduce((sum, b) => sum + (b.npuUtilization || 0), 0) / benchmarks.length * 100)
      : 0
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="glass sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </Link>
          <div className="flex items-center gap-3">
            <BarChart3 className="w-6 h-6 text-orange-400" />
            <span className="text-xl font-bold gradient-text">Performance Benchmarks</span>
          </div>
        </div>
      </header>

      {/* Stats Overview */}
      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {[
              { 
                label: "Average Score", 
                value: stats.averageScore.toLocaleString(), 
                icon: TrendingUp,
                color: "text-green-400"
              },
              { 
                label: "Total Test Runs", 
                value: stats.totalRuns.toString(), 
                icon: BarChart3,
                color: "text-blue-400"
              },
              { 
                label: "Avg NPU Utilization", 
                value: `${stats.avgNpuUtil}%`, 
                icon: Zap,
                color: "text-orange-400"
              }
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="glass rounded-2xl p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                  <Award className="w-6 h-6 text-gray-500" />
                </div>
                <div className={`text-4xl font-bold ${stat.color} mb-2`}>{stat.value}</div>
                <div className="text-gray-400">{stat.label}</div>
              </motion.div>
            ))}
          </div>

          {/* Benchmark Tests */}
          <div className="glass rounded-3xl p-8 mb-12">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold">Run Performance Tests</h2>
              <button 
                onClick={fetchBenchmarks}
                className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
              >
                <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </button>
            </div>

            <div className="space-y-4">
              {testCategories.map((test, i) => (
                <motion.div
                  key={test.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-center gap-6 p-6 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <div className="text-4xl">{test.icon}</div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold mb-1">{test.name}</h3>
                    <p className="text-gray-400 text-sm">{test.description}</p>
                  </div>
                  <button
                    onClick={() => runBenchmark(test.name)}
                    disabled={runningTest !== null}
                    className={`px-6 py-3 rounded-xl font-medium transition-all ${
                      runningTest === test.name
                        ? 'bg-orange-500/50 cursor-wait'
                        : 'btn-primary'
                    } disabled:opacity-50`}
                  >
                    {runningTest === test.name ? (
                      <span className="flex items-center gap-2">
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        Running...
                      </span>
                    ) : (
                      "Run Test"
                    )}
                  </button>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Results History */}
          <div className="glass rounded-3xl p-8">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold">Recent Results</h2>
              <button className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                <Download className="w-5 h-5" />
                Export CSV
              </button>
            </div>

            {loading ? (
              <div className="text-center py-12 text-gray-400">Loading results...</div>
            ) : benchmarks.length === 0 ? (
              <div className="text-center py-12 text-gray-400">
                No benchmark results yet. Run some tests above!
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b border-white/10">
                      <th className="pb-4 text-gray-400 font-medium">Test Name</th>
                      <th className="pb-4 text-gray-400 font-medium">Score</th>
                      <th className="pb-4 text-gray-400 font-medium">NPU Util</th>
                      <th className="pb-4 text-gray-400 font-medium">CPU Util</th>
                      <th className="pb-4 text-gray-400 font-medium">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {benchmarks.map((benchmark, i) => (
                      <motion.tr
                        key={benchmark.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.05 }}
                        className="border-b border-white/5"
                      >
                        <td className="py-4">
                          <div className="flex items-center gap-2">
                            <Cpu className="w-4 h-4 text-orange-400" />
                            {benchmark.testName}
                          </div>
                        </td>
                        <td className="py-4">
                          <span className="text-green-400 font-bold">{benchmark.score.toLocaleString()}</span>
                        </td>
                        <td className="py-4">
                          <div className="flex items-center gap-2">
                            <Zap className="w-4 h-4 text-yellow-400" />
                            {Math.round((benchmark.npuUtilization || 0) * 100)}%
                          </div>
                        </td>
                        <td className="py-4 text-gray-400">
                          {Math.round((benchmark.cpuUtilization || 0) * 100)}%
                        </td>
                        <td className="py-4 text-gray-400 text-sm">
                          {new Date(benchmark.createdAt).toLocaleDateString()}
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Comparison Chart */}
          <div className="glass rounded-3xl p-8 mt-12">
            <h2 className="text-2xl font-bold mb-8">Snapdragon vs Competition</h2>
            <div className="space-y-6">
              {[
                { name: "Image Classification", snapdragon: 9847, competitor: 6234 },
                { name: "NLP Processing", snapdragon: 9523, competitor: 5891 },
                { name: "Object Detection", snapdragon: 9234, competitor: 5623 },
                { name: "Speech Recognition", snapdragon: 9612, competitor: 6123 },
                { name: "Power Efficiency", snapdragon: 9891, competitor: 4523 }
              ].map((item, i) => (
                <motion.div
                  key={item.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-300">{item.name}</span>
                    <span className="text-orange-400 font-bold">
                      +{Math.round(((item.snapdragon - item.competitor) / item.competitor) * 100)}% faster
                    </span>
                  </div>
                  <div className="relative h-8 bg-white/5 rounded-xl overflow-hidden">
                    <div
                      className="absolute left-0 top-0 h-full bg-gradient-to-r from-orange-500 to-red-500 flex items-center justify-end pr-3"
                      style={{ width: `${(item.snapdragon / 10000) * 100}%` }}
                    >
                      <span className="text-xs font-bold text-white">Snapdragon: {item.snapdragon}</span>
                    </div>
                    <div
                      className="absolute left-0 top-0 h-full bg-gray-600/50 flex items-center justify-end pr-3"
                      style={{ width: `${(item.competitor / 10000) * 100}%` }}
                    >
                      <span className="text-xs text-gray-400">Other: {item.competitor}</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
