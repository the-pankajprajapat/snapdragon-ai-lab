import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Snapdragon® AI Lab - Build & Present Challenge",
  description: "Experience the future of AI computing on Snapdragon-powered HP PCs. Build innovative AI applications that leverage the power of Hexagon NPU for unprecedented performance and efficiency.",
  keywords: ["Snapdragon", "AI", "HP PC", "NPU", "Machine Learning", "Neural Processing", "AI Challenge"],
  openGraph: {
    title: "Snapdragon® AI Lab - Build & Present Challenge",
    description: "Build innovative AI applications optimized for Snapdragon-powered HP PCs",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="antialiased">{children}</body>
    </html>
  );
}
