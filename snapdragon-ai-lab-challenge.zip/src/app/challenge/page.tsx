"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Trophy, 
  Calendar, 
  Users, 
  DollarSign, 
  FileText, 
  CheckCircle, 
  ArrowLeft,
  Upload,
  Send
} from "lucide-react";
import Link from "next/link";

export default function ChallengePage() {
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    email: "",
    category: "innovation",
    description: ""
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await fetch("/api/presentations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        setSubmitted(true);
      }
    } catch (error) {
      console.error("Submission error:", error);
    }
  };

  const prizes = [
    { place: "1st Place", amount: "$10,000", icon: "🥇", color: "from-yellow-500 to-orange-500" },
    { place: "2nd Place", amount: "$5,000", icon: "🥈", color: "from-gray-400 to-gray-600" },
    { place: "3rd Place", amount: "$2,500", icon: "🥉", color: "from-orange-700 to-orange-900" },
    { place: "Best Innovation", amount: "$2,000", icon: "💡", color: "from-purple-500 to-pink-500" },
    { place: "Best Performance", amount: "$2,000", icon: "⚡", color: "from-cyan-500 to-blue-500" }
  ];

  const timeline = [
    { date: "March 1, 2026", event: "Challenge Launch", completed: true },
    { date: "April 15, 2026", event: "Submission Deadline", completed: false },
    { date: "May 1-7, 2026", event: "Judging Period", completed: false },
    { date: "May 15, 2026", event: "Winner Announcement", completed: false }
  ];

  const categories = [
    {
      id: "ai_vision",
      name: "AI Vision & Imaging",
      description: "Computer vision, image processing, object detection, facial recognition",
      icon: "👁️"
    },
    {
      id: "nlp",
      name: "Natural Language Processing",
      description: "Text analysis, sentiment detection, translation, summarization",
      icon: "💬"
    },
    {
      id: "performance",
      name: "Performance Optimization",
      description: "NPU acceleration, power efficiency, latency reduction",
      icon: "⚡"
    },
    {
      id: "innovation",
      name: "Breakthrough Innovation",
      description: "Novel AI applications, creative use cases, unique solutions",
      icon: "🚀"
    }
  ];

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="glass sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </Link>
          <div className="flex items-center gap-3">
            <Trophy className="w-6 h-6 text-orange-400" />
            <span className="text-xl font-bold gradient-text">AI Lab Challenge</span>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Build & Present <span className="gradient-text">Challenge</span>
            </h1>
            <p className="text-xl text-gray-400 mb-8">
              Showcase your AI innovation on Snapdragon-powered HP PCs and win amazing prizes
            </p>
          </motion.div>

          {/* Prize Pool */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass rounded-3xl p-8 mb-12"
          >
            <div className="flex items-center justify-center gap-3 mb-6">
              <DollarSign className="w-8 h-8 text-green-400" />
              <span className="text-3xl font-bold text-green-400">$21,500 Total Prize Pool</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {prizes.map((prize, i) => (
                <motion.div
                  key={i}
                  whileHover={{ scale: 1.05 }}
                  className={`rounded-2xl p-4 bg-gradient-to-br ${prize.color}`}
                >
                  <div className="text-3xl mb-2">{prize.icon}</div>
                  <div className="font-bold text-white">{prize.place}</div>
                  <div className="text-white/80 text-sm">{prize.amount}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 px-6 bg-gradient-to-b from-transparent via-card-bg/30 to-transparent">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Challenge Timeline</h2>
          <div className="space-y-4">
            {timeline.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex items-center gap-4 p-4 glass rounded-xl"
              >
                <div className={`w-4 h-4 rounded-full ${item.completed ? 'bg-green-400' : 'bg-gray-600'}`} />
                <Calendar className="w-5 h-5 text-gray-400" />
                <span className="text-gray-300 flex-1">{item.date}</span>
                <span className="font-medium text-white">{item.event}</span>
                {item.completed && <CheckCircle className="w-5 h-5 text-green-400" />}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Competition Categories</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((cat, i) => (
              <motion.div
                key={cat.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ scale: 1.03 }}
                onClick={() => setFormData({ ...formData, category: cat.id })}
                className={`glass rounded-2xl p-6 cursor-pointer transition-all ${
                  formData.category === cat.id ? 'border-orange-500 border-2' : 'border-transparent'
                }`}
              >
                <div className="text-4xl mb-4">{cat.icon}</div>
                <h3 className="text-xl font-bold mb-2">{cat.name}</h3>
                <p className="text-gray-400 text-sm">{cat.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Submission Form */}
      <section className="py-16 px-6 bg-gradient-to-b from-transparent via-card-bg/30 to-transparent">
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass rounded-3xl p-8"
          >
            <h2 className="text-3xl font-bold mb-2">Submit Your Entry</h2>
            <p className="text-gray-400 mb-8">Fill out the form below to register your project</p>

            {submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12"
              >
                <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">Submission Received!</h3>
                <p className="text-gray-400">We'll review your entry and contact you soon.</p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Project Title</label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-orange-500"
                    placeholder="Enter your project title"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Your Name</label>
                    <input
                      type="text"
                      required
                      value={formData.author}
                      onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                      className="w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-orange-500"
                      placeholder="Full name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-orange-500"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-orange-500"
                  >
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Project Description</label>
                  <textarea
                    required
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={5}
                    className="w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-orange-500 resize-none"
                    placeholder="Describe your AI project, how it uses Snapdragon NPU, and what makes it innovative..."
                  />
                </div>

                <div className="glass rounded-xl p-4 border-dashed border-2 border-white/10 text-center">
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-400 text-sm">Drag and drop your presentation files here (optional)</p>
                  <p className="text-gray-500 text-xs mt-1">PDF, PPTX, or video formats accepted</p>
                </div>

                <button
                  type="submit"
                  className="w-full btn-primary py-4 flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  Submit Entry
                </button>
              </form>
            )}
          </motion.div>
        </div>
      </section>

      {/* Requirements */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Submission Requirements</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              { title: "Working Prototype", desc: "A functional AI application demonstrating Snapdragon NPU capabilities" },
              { title: "Source Code", desc: "Complete source code with documentation and setup instructions" },
              { title: "Presentation", desc: "5-10 minute presentation explaining your solution and innovation" },
              { title: "Performance Metrics", desc: "Benchmarks showing NPU acceleration and efficiency gains" },
              { title: "Video Demo", desc: "Screen recording demonstrating your application in action" },
              { title: "Technical Write-up", desc: "Detailed explanation of your approach and implementation" }
            ].map((req, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex items-start gap-4 p-4 glass rounded-xl"
              >
                <FileText className="w-6 h-6 text-orange-400 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold mb-1">{req.title}</h3>
                  <p className="text-gray-400 text-sm">{req.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass rounded-3xl p-12"
          >
            <Users className="w-12 h-12 text-orange-400 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-4">Ready to Compete?</h2>
            <p className="text-gray-400 mb-8 max-w-xl mx-auto">
              Join innovators from around the world in showcasing the power of AI on Snapdragon platforms. 
              Your breakthrough could be the next big thing in edge AI.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary px-8 py-4">
                Start Building Now
              </button>
              <button className="btn-secondary px-8 py-4">
                Download SDK
              </button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
