import { pgTable, text, timestamp, integer, jsonb, uuid, real } from "drizzle-orm/pg-core";

export const aiDemos = pgTable("ai_demos", {
  id: uuid("id").primaryKey().defaultRandom(),
  demoType: text("demo_type").notNull(), // 'image', 'text', 'benchmark'
  inputData: jsonb("input_data"),
  resultData: jsonb("result_data"),
  processingTimeMs: real("processing_time_ms"),
  snapdragonOptimized: text("snapdragon_optimized").default("true"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const benchmarks = pgTable("benchmarks", {
  id: uuid("id").primaryKey().defaultRandom(),
  testName: text("test_name").notNull(),
  score: real("score").notNull(),
  deviceInfo: jsonb("device_info"),
  npuUtilization: real("npu_utilization"),
  cpuUtilization: real("cpu_utilization"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const presentations = pgTable("presentations", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  description: text("description"),
  slides: jsonb("slides"),
  author: text("author"),
  category: text("category"), // 'ai_vision', 'nlp', 'performance', 'innovation'
  views: integer("views").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
